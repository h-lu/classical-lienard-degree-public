# Classical polynomial Liénard systems at fixed degree

The [article](main.pdf) proves a lower bound of \(\lceil(7n-48)/2\rceil\) coexisting hyperbolic limit cycles at each exact primitive degree \(n\ge14\). The [electronic supplement](low-degree-supplement.pdf) gives the low-degree results, including a nineteen-cycle existence theorem at degree twelve and a six-cycle certificate for a specified rational field. A second rational field attains five cycles in the weak full-return domain.

## Reproduce both papers and their certificates

The complete editable archive is `source-reproduction.tar.gz`. Place the accompanying `.sha256` file beside it and run the following commands.

```sh
sha256sum -c source-reproduction.tar.gz.sha256
tar -xzf source-reproduction.tar.gz
cd classical-lienard-degree
./reproduce.sh
```

The driver checks the scientific inventory, rebuilds both PDFs from the [LaTeX sources](source/main.tex), regenerates the [certificate archive](source/certificates.tar.gz) and replays its four reference transcripts. The [build instructions](source/BUILD.md) list the dependencies and single-document commands. For the finite checks alone, extract the certificate archive and follow its [replay guide](source/REPLAY-GUIDE.md).

The [certificate index](CERTIFICATE-INDEX.md) links the exact inputs and outputs to their mathematical use. The [mechanism note](MECHANISM.md) gives the relative-gap estimate, its hypotheses, degree cost and a scalar passage illustrating its limit of applicability.
